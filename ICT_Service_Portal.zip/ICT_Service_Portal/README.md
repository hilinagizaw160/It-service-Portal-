# ICT Service Portal

A clean, modern PHP web application for submitting and managing ICT service requests (hardware, software, network, etc.).

Built for **freelance / client delivery** and portfolio use.

---

## Features

- User registration & login (with pending approval workflow)
- Submit service requests with category, priority, description and file attachment
- Track request status (Pending → Approved → In Progress → Resolved / Closed)
- Dashboard with statistics
- Notifications
- Profile management
- Admin panel:
  - Manage users (approve / activate / deactivate)
  - Manage all requests (change status, assign)
  - Activity log
  - Basic reports
- Responsive UI (Inter font + Font Awesome)
- Secure file uploads (extension + size validation)
- Activity logging
- PDO prepared statements throughout

---

## Requirements

- PHP 7.4+ (8.x recommended)
- MySQL 5.7+ / MariaDB 10.3+
- Apache with `mod_rewrite` (or Nginx)
- XAMPP / WAMP / Laragon / Live server

---

## Installation (Local)

1. **Extract** this folder into your web root  
   Example: `C:\xampp\htdocs\ICT_Service_Portal` or `/var/www/html/ICT_Service_Portal`

2. **Create the database**  
   - Open phpMyAdmin  
   - Import the file: `database/service_portal.sql`  
   - Or run the SQL in the MySQL console

3. **Configure database credentials**  
   Edit `includes/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');          // your MySQL password
   define('DB_NAME', 'service_portal');
   ```

4. **Update site URL** (optional but recommended)
   ```php
   define('SITE_URL', 'http://localhost/ICT_Service_Portal/');
   ```

5. **Set folder permissions** (Linux)
   ```bash
   chmod -R 755 uploads logs
   chmod -R 777 uploads/requests logs
   ```

6. Open in browser:
   ```
   http://localhost/ICT_Service_Portal/
   ```

---

## Default Login

| Role        | Username | Password   |
|-------------|----------|------------|
| Super Admin | admin    | Admin@123  |

> Sample users also use the password `password` (you should change them in production).

---

## Project Structure

```
ICT_Service_Portal/
├── index.php              # Landing page
├── login.php / register.php / logout.php
├── dashboard.php
├── request.php            # Submit new request
├── view_request.php
├── profile.php
├── search.php
├── notification.php
├── chat.php               # Placeholder
├── user_guide.php
├── includes/
│   ├── config.php         # All settings
│   ├── db.php
│   ├── session.php
│   ├── functions.php
│   ├── header.php / footer.php
│   ├── mail.php
│   └── upload.php
├── admin/
│   ├── admin_login.php
│   ├── admin_dashboard.php
│   ├── manage_users.php
│   ├── manage_requests.php
│   ├── activity_log.php
│   ├── reports.php
│   └── settings.php
├── assets/css/ & assets/js/
├── uploads/requests/      # Protected upload folder
├── database/service_portal.sql
└── logs/
```

---

## Security Notes (for client delivery)

- Passwords are hashed with `password_hash()` (bcrypt)
- All database queries use PDO prepared statements
- File uploads are validated by extension + size and stored with sanitized names
- Uploaded PHP files cannot be executed (`.htaccess` protection)
- Error display is turned off in production (`display_errors = 0`)
- Session-based authentication with role checks

**Still recommended before going live:**
- Change the default admin password
- Enable HTTPS
- Use a strong database password
- Consider adding CSRF tokens on forms
- Configure real SMTP credentials in `config.php` for emails

---

## Customization for Clients

1. Change `SITE_NAME` and `SITE_URL` in `includes/config.php`
2. Replace logo / colors in `assets/css/style.css`
3. Update email templates in `includes/mail.php`
4. Add more categories via the database or a future admin UI

---

## Support

This project was cleaned and structured for professional freelance delivery.  
All previous issues (spaces in filenames, missing includes, broken paths, empty critical files) have been fixed.

---

**Ready to deliver.**
