<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
checkLogin();

$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($request_id <= 0) {
    setFlashMessage('danger', 'Invalid request ID');
    header('Location: dashboard.php');
    exit();
}

$request = getRequestById($request_id);

if (!$request) {
    setFlashMessage('danger', 'Request not found');
    header('Location: dashboard.php');
    exit();
}

// Check permission
if (!isAdmin() && $request['user_id'] != $_SESSION['user_id']) {
    setFlashMessage('danger', 'You do not have permission to view this request');
    header('Location: dashboard.php');
    exit();
}

$comments = getRequestComments($request_id);

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = sanitizeInput($_POST['comment'] ?? '');
    $attachment = null;
    
    if (!empty($comment)) {
        // Handle file upload for comment
        if (isset($_FILES['comment_attachment']) && $_FILES['comment_attachment']['error'] === UPLOAD_ERR_OK) {
            $upload_result = uploadFile($_FILES['comment_attachment']);
            if ($upload_result['success']) {
                $attachment = $upload_result['filename'];
            }
        }
        
        addRequestComment($request_id, $_SESSION['user_id'], $comment, $attachment);
        
        // Notify the request owner
        if ($_SESSION['user_id'] != $request['user_id']) {
            addNotification(
                $request['user_id'],
                'comment',
                "New comment on Request #{$request_id}",
                "Someone commented on your request: {$request['title']}",
                SITE_URL . "view_request.php?id={$request_id}"
            );
        }
        
        setFlashMessage('success', 'Comment added successfully');
        header("Location: view_request.php?id=" . $request_id);
        exit();
    }
}

// Handle status update (admin only)
if (isAdmin() && isset($_POST['update_status'])) {
    $status = sanitizeInput($_POST['status']);
    $request = getRequestById($request_id);
    $old_status = $request['status'];
    
    updateRequestStatus($request_id, $status, $_SESSION['user_id']);
    
    // Notify user
    $user = getUserById($request['user_id']);
    addNotification(
        $request['user_id'],
        'status_update',
        "Request #{$request_id} Status Updated",
        "Your request '{$request['title']}' status changed from " . ucfirst($old_status) . " to " . ucfirst($status),
        SITE_URL . "view_request.php?id={$request_id}"
    );
    
    setFlashMessage('success', 'Request status updated successfully');
    header("Location: view_request.php?id=" . $request_id);
    exit();
}

// Handle assignment (admin only)
if (isAdmin() && isset($_POST['assign_to'])) {
    $assigned_to = (int)$_POST['assigned_to'];
    assignRequest($request_id, $assigned_to, $_SESSION['user_id']);
    
    // Notify assigned user
    if ($assigned_to) {
        $assigned_user = getUserById($assigned_to);
        addNotification(
            $assigned_to,
            'assignment',
            "Request #{$request_id} Assigned",
            "You have been assigned to request: {$request['title']}",
            SITE_URL . "view_request.php?id={$request_id}"
        );
    }
    
    setFlashMessage('success', 'Request assigned successfully');
    header("Location: view_request.php?id=" . $request_id);
    exit();
}

// Get users for assignment (admin only)
$users = [];
if (isAdmin()) {
    try {
        $stmt = $conn->query("SELECT id, full_name FROM users WHERE role IN ('user', 'admin') ORDER BY full_name");
        $users = $stmt->fetchAll();
    } catch (PDOException $e) {
        $users = [];
    }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="request-details-page">
    <div class="request-header">
        <div class="request-title">
            <h2><?php echo htmlspecialchars($request['title']); ?></h2>
            <div class="request-meta" style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.5rem;">
                <span class="badge badge-priority-<?php echo $request['priority']; ?>">
                    <i class="fas fa-flag"></i> <?php echo ucfirst($request['priority']); ?>
                </span>
                <span class="badge badge-status-<?php echo $request['status']; ?>">
                    <i class="fas fa-circle"></i> <?php echo str_replace('_', ' ', ucfirst($request['status'])); ?>
                </span>
                <span class="badge badge-info">
                    <i class="fas fa-tag"></i> <?php echo $request['request_type']; ?>
                </span>
                <?php if ($request['category_name']): ?>
                    <span class="badge" style="background: <?php echo $request['category_color'] ?? '#4F46E5'; ?>; color: white;">
                        <i class="fas fa-folder"></i> <?php echo htmlspecialchars($request['category_name']); ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <a href="dashboard.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
        <div class="card">
            <h4><i class="fas fa-info-circle"></i> Request Information</h4>
            <div style="margin-top: 0.5rem;">
                <p><strong>Request ID:</strong> #<?php echo $request['id']; ?></p>
                <p><strong>Submitted By:</strong> <?php echo htmlspecialchars($request['requester_name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($request['requester_email']); ?></p>
                <p><strong>Submitted On:</strong> <?php echo date('F d, Y \a\t h:i A', strtotime($request['created_at'])); ?></p>
                <?php if ($request['assigned_to']): ?>
                    <p><strong>Assigned To:</strong> <?php echo htmlspecialchars($request['assignee_name']); ?></p>
                <?php endif; ?>
                <?php if ($request['approved_at']): ?>
                    <p><strong>Approved On:</strong> <?php echo date('F d, Y \a\t h:i A', strtotime($request['approved_at'])); ?></p>
                <?php endif; ?>
                <?php if ($request['resolved_at']): ?>
                    <p><strong>Resolved On:</strong> <?php echo date('F d, Y \a\t h:i A', strtotime($request['resolved_at'])); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card">
            <h4><i class="fas fa-paperclip"></i> Attachment</h4>
            <?php if ($request['attachment']): ?>
                <div style="margin-top: 0.5rem; padding: 1rem; background: #f8f9fa; border-radius: 8px; text-align: center;">
                    <i class="fas fa-file" style="font-size: 2rem; color: #4F46E5;"></i>
                    <p><strong><?php echo htmlspecialchars($request['attachment_name'] ?? 'File'); ?></strong></p>
                    <a href="uploads/requests/<?php echo $request['attachment']; ?>" class="btn btn-sm btn-primary" target="_blank">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            <?php else: ?>
                <p style="color: #6c757d; margin-top: 0.5rem;">No attachment</p>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card" style="margin-bottom: 1.5rem;">
        <h4><i class="fas fa-align-left"></i> Description</h4>
        <p style="margin-top: 0.5rem; white-space: pre-wrap;"><?php echo nl2br(htmlspecialchars($request['description'])); ?></p>
    </div>
    
    <?php if (isAdmin()): ?>
        <div class="card" style="margin-bottom: 1.5rem; background: #f0f4ff; border-color: #4F46E5;">
            <h4><i class="fas fa-user-shield"></i> Admin Actions</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1rem;">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="status">Update Status</label>
                        <select name="status" id="status" class="form-control">
                            <?php foreach (getStatusOptions() as $key => $value): ?>
                                <option value="<?php echo $key; ?>" <?php echo $request['status'] === $key ? 'selected' : ''; ?>>
                                    <?php echo $value; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="update_status" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Status
                    </button>
                </form>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="assigned_to">Assign To</label>
                        <select name="assigned_to" id="assigned_to" class="form-control">
                            <option value="">-- Unassigned --</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>" <?php echo $request['assigned_to'] == $user['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($user['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="assign_to" class="btn btn-info">
                        <i class="fas fa-user-check"></i> Assign
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="comments-section">
        <h4><i class="fas fa-comments"></i> Comments (<?php echo count($comments); ?>)</h4>
        
        <?php if (empty($comments)): ?>
            <div class="no-comments" style="padding: 1.5rem; text-align: center; color: #6c757d;">
                <i class="fas fa-comment-slash" style="font-size: 2rem;"></i>
                <p>No comments yet</p>
            </div>
        <?php else: ?>
            <div class="comments-list" style="margin-top: 1rem;">
                <?php foreach ($comments as $comment): ?>
                    <div style="padding: 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.8rem; border-left: 4px solid <?php echo $comment['role'] === 'admin' ? '#4F46E5' : '#e2e8f0'; ?>;">
                        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.3rem;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                <i class="fas fa-user-circle" style="font-size: 1.2rem; color: #4F46E5;"></i>
                                <strong><?php echo htmlspecialchars($comment['full_name']); ?></strong>
                                <?php if ($comment['role'] === 'admin'): ?>
                                    <span class="badge badge-admin" style="background: #4F46E5; color: white; font-size: 0.7rem;">
                                        <i class="fas fa-user-shield"></i> Admin
                                    </span>
                                <?php endif; ?>
                            </div>
                            <span style="color: #6c757d; font-size: 0.8rem;">
                                <?php echo date('M d, Y h:i A', strtotime($comment['created_at'])); ?>
                            </span>
                        </div>
                        <div style="margin-top: 0.3rem; white-space: pre-wrap;">
                            <?php echo nl2br(htmlspecialchars($comment['comment'])); ?>
                        </div>
                        <?php if ($comment['attachment']): ?>
                            <div style="margin-top: 0.5rem;">
                                <a href="uploads/requests/<?php echo $comment['attachment']; ?>" class="btn btn-sm btn-outline" target="_blank">
                                    <i class="fas fa-paperclip"></i> View Attachment
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="comment-form" style="margin-top: 1.5rem;">
            <h5><i class="fas fa-pen"></i> Add Comment</h5>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <textarea name="comment" rows="3" placeholder="Write your comment here..." required></textarea>
                </div>
                <div class="form-group">
                    <label for="comment_attachment">Attach File (optional)</label>
                    <input type="file" id="comment_attachment" name="comment_attachment" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane"></i> Post Comment
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>