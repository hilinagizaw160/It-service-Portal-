<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header('Location: admin_dashboard.php');
        exit();
    } else {
        header('Location: ../dashboard.php');
        exit();
    }
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        try {
            $stmt = $conn->prepare("
                SELECT id, username, password, full_name, email, role 
                FROM users 
                WHERE (username = ? OR email = ?) 
                AND role IN ('admin', 'super_admin')
            ");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                
                logActivity($user['id'], 'admin_login', 'Admin logged in');
                
                setFlashMessage('success', 'Welcome back, ' . $user['full_name'] . '!');
                header('Location: admin_dashboard.php');
                exit();
            } else {
                $error = 'Invalid admin credentials. Please check your username and password.';
            }
        } catch (PDOException $e) {
            $error = 'Login failed: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - ICT Service Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-auth {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            padding: 1.5rem;
        }
        .admin-auth .auth-card {
            background: #ffffff;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 420px;
        }
        .admin-auth .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .admin-auth .auth-header i {
            font-size: 2.5rem;
            color: #4F46E5;
            background: rgba(79, 70, 229, 0.1);
            padding: 0.8rem;
            border-radius: 50%;
        }
        .admin-auth .auth-header h2 {
            font-size: 1.5rem;
            margin-top: 0.5rem;
        }
        .admin-auth .auth-header p {
            color: #64748b;
            font-size: 0.9rem;
        }
        .admin-auth .form-group {
            margin-bottom: 1.2rem;
        }
        .admin-auth .form-group label {
            display: block;
            font-weight: 500;
            color: #334155;
            font-size: 0.9rem;
            margin-bottom: 0.3rem;
        }
        .admin-auth .form-group label i {
            color: #4F46E5;
            margin-right: 4px;
        }
        .admin-auth .form-group input {
            width: 100%;
            padding: 0.6rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s;
            background: #f8fafc;
        }
        .admin-auth .form-group input:focus {
            outline: none;
            border-color: #4F46E5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
            background: #ffffff;
        }
        .admin-auth .btn-login {
            width: 100%;
            padding: 0.7rem;
            background: #4F46E5;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .admin-auth .btn-login:hover {
            background: #4338CA;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
        }
        .admin-auth .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid #e2e8f0;
        }
        .admin-auth .auth-footer a {
            color: #4F46E5;
            text-decoration: none;
            font-weight: 500;
        }
        .admin-auth .auth-footer a:hover {
            text-decoration: underline;
        }
        .admin-auth .alert {
            padding: 0.8rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        .admin-auth .alert-danger {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        .admin-auth .security-badge {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.75rem;
            color: #94a3b8;
        }
        .admin-auth .security-badge i {
            margin-right: 0.3rem;
        }
        
        /* Password Toggle */
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-wrapper input {
            width: 100%;
            padding-right: 45px;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #94a3b8;
            font-size: 1.1rem;
            padding: 5px;
            transition: color 0.3s;
        }
        .toggle-password:hover {
            color: #4F46E5;
        }
        .toggle-password:focus {
            outline: none;
        }
        
        @media (max-width: 480px) {
            .admin-auth .auth-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-auth">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-user-shield"></i>
                <h2>Admin Login</h2>
                <p>Enter your admin credentials to continue</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username or Email
                    </label>
                    <input type="text" id="username" name="username" 
                           placeholder="Enter admin username or email" 
                           value="<?php echo htmlspecialchars($username); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" 
                               placeholder="Enter your password" required>
                        <button type="button" class="toggle-password" onclick="togglePassword('password', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login as Admin
                </button>
            </form>
            
            <div class="auth-footer">
                <p><a href="../login.php"><i class="fas fa-arrow-left"></i> Back to User Login</a></p>
            </div>
            
            <div class="security-badge">
                <i class="fas fa-shield-alt"></i> Secure Admin Panel
            </div>
        </div>
    </div>
    
    <script>
    function togglePassword(inputId, button) {
        const input = document.getElementById(inputId);
        const icon = button.querySelector('i');
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
    </script>
</body>
</html>