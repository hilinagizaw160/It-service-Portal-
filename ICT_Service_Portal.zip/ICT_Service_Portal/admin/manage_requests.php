<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mail.php';
checkAdmin();

// ============================================
// HANDLE STATUS UPDATE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $status = sanitizeInput($_POST['status']);
    
    try {
        // Get old status and request info
        $old_request = getRequestById($request_id);
        $old_status = $old_request['status'];
        
        updateRequestStatus($request_id, $status, $_SESSION['user_id']);
        
        // Send notification to user
        $user = getUserById($old_request['user_id']);
        $email_body = getStatusUpdateEmail($old_request, $user, ucfirst($old_status), ucfirst($status));
        sendEmail($user['email'], "Request #{$request_id} Status Updated", $email_body);
        
        addNotification(
            $old_request['user_id'],
            'status_update',
            "Request #{$request_id} Status Updated",
            "Your request '{$old_request['title']}' status changed from " . ucfirst($old_status) . " to " . ucfirst($status),
            SITE_URL . "view_request.php?id={$request_id}"
        );
        
        setFlashMessage('success', '✅ Request status updated successfully!');
    } catch (PDOException $e) {
        setFlashMessage('danger', '❌ Failed to update status: ' . $e->getMessage());
    }
    header('Location: manage_requests.php');
    exit();
}

// ============================================
// HANDLE REQUEST DELETION
// ============================================
if (isset($_GET['delete'])) {
    $request_id = (int)$_GET['delete'];
    
    try {
        deleteRequest($request_id);
        logActivity($_SESSION['user_id'], 'request_deleted', "Deleted request #{$request_id}");
        setFlashMessage('success', '✅ Request deleted successfully!');
    } catch (PDOException $e) {
        setFlashMessage('danger', '❌ Failed to delete request: ' . $e->getMessage());
    }
    header('Location: manage_requests.php');
    exit();
}

// ============================================
// GET ALL REQUESTS
// ============================================
try {
    $stmt = $conn->query("
        SELECT r.*, u.full_name as user_name, u.email as user_email, c.name as category_name 
        FROM service_requests r 
        LEFT JOIN users u ON r.user_id = u.id 
        LEFT JOIN request_categories c ON r.category_id = c.id 
        ORDER BY r.created_at DESC
    ");
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    $requests = [];
}

// Get all users for assignment
try {
    $stmt = $conn->query("SELECT id, full_name FROM users WHERE role IN ('user', 'admin') ORDER BY full_name");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

// Get categories
try {
    $stmt = $conn->query("SELECT * FROM request_categories WHERE is_active = 1 ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Requests - ICT Service Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar admin-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <a href="admin_dashboard.php">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Panel</span>
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="admin_dashboard.php"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                <li><a href="manage_requests.php"><i class="fas fa-tasks"></i> Requests</a></li>
                <li><a href="manage_users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="register_admin.php"><i class="fas fa-user-plus"></i> Create Admin</a></li>
                <li class="user-profile">
                    <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    
    <main class="container">
        <div class="dashboard-header">
            <div>
                <h1><i class="fas fa-tasks"></i> Manage Requests</h1>
                <p>View and manage all service requests</p>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="../request.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> New Request
                </a>
                <a href="admin_dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        
        <?php $flash = getFlashMessage(); if ($flash): ?>
            <div class="alert alert-<?php echo $flash['type']; ?> alert-dismissible">
                <?php echo $flash['message']; ?>
                <button class="alert-close" onclick="this.parentElement.style.display='none'">&times;</button>
            </div>
        <?php endif; ?>
        
        <?php if (empty($requests)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>No Requests</h3>
                <p>There are no service requests in the system.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Category</th>
                            <th>Title</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td>#<?php echo $request['id']; ?></td>
                                <td>
                                    <div><strong><?php echo htmlspecialchars($request['user_name']); ?></strong></div>
                                    <small><?php echo htmlspecialchars($request['user_email']); ?></small>
                                </td>
                                <td>
                                    <?php if ($request['category_name']): ?>
                                        <span class="badge badge-info"><?php echo htmlspecialchars($request['category_name']); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Uncategorized</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($request['title']); ?></td>
                                <td>
                                    <span class="badge badge-priority-<?php echo $request['priority']; ?>">
                                        <?php echo ucfirst($request['priority']); ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <select name="status" onchange="this.form.submit()" class="form-control form-control-sm" style="width: auto; padding: 2px 8px;">
                                            <option value="pending" <?php echo $request['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="approved" <?php echo $request['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                            <option value="in_progress" <?php echo $request['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                            <option value="resolved" <?php echo $request['status'] === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                                            <option value="closed" <?php echo $request['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
                                            <option value="rejected" <?php echo $request['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                        </select>
                                        <input type="hidden" name="update_status" value="1">
                                    </form>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                <td>
                                    <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                        <a href="../view_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($request['attachment']): ?>
                                            <a href="../uploads/requests/<?php echo $request['attachment']; ?>" class="btn btn-sm btn-secondary" title="Download Attachment" target="_blank">
                                                <i class="fas fa-paperclip"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="?delete=<?php echo $request['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> ICT Service Portal - Admin Panel</p>
        </div>
    </footer>
    
    <script src="../assets/js/script.js"></script>
</body>
</html>