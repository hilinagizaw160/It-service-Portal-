<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
checkAdmin();
include __DIR__ . '/../includes/header.php';
?>
<div class="card" style="max-width:800px;margin:2rem auto;padding:2rem;">
    <h2><i class="fas fa-key"></i> Permissions</h2>
    <p style="color:#64748b;">Fine-grained permission management will be available in a future update. Currently roles are controlled via the user role field (user / admin / super_admin).</p>
    <a href="admin_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back</a>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
