<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
checkAdmin();

// Get all statistics
$stats = getRequestStats();
$category_stats = getCategoryStats();

// Get recent activity
try {
    $stmt = $conn->query("
        SELECT a.*, u.full_name 
        FROM activity_logs a 
        JOIN users u ON a.user_id = u.id 
        ORDER BY a.created_at DESC 
        LIMIT 10
    ");
    $recent_activity = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_activity = [];
}

// Get pending users count
try {
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'pending'");
    $pending_users = $stmt->fetch()['count'];
} catch (PDOException $e) {
    $pending_users = 0;
}

// Get pending requests
try {
    $stmt = $conn->query("SELECT COUNT(*) as count FROM service_requests WHERE status = 'pending'");
    $pending_requests = $stmt->fetch()['count'];
} catch (PDOException $e) {
    $pending_requests = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ICT Service Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 2rem;
            margin: 0.5rem 0;
        }
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .stat-card .stat-icon {
            font-size: 2rem;
        }
        .bg-primary { background: #4F46E5; color: white; }
        .bg-success { background: #22C55E; color: white; }
        .bg-warning { background: #F59E0B; color: white; }
        .bg-danger { background: #EF4444; color: white; }
        .bg-info { background: #3B82F6; color: white; }
        .bg-secondary { background: #6B7280; color: white; }
        
        .activity-list {
            list-style: none;
            padding: 0;
        }
        .activity-list li {
            padding: 10px 15px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .activity-list li:last-child {
            border-bottom: none;
        }
        .activity-time {
            color: #6c757d;
            font-size: 0.8rem;
        }
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <nav class="navbar admin-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <a href="admin_dashboard.php">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Panel</span>
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="admin_dashboard.php"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                <li><a href="manage_requests.php"><i class="fas fa-tasks"></i> Requests</a></li>
                <li><a href="manage_users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="register_admin.php"><i class="fas fa-user-plus"></i> Create Admin</a></li>
                <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
                <li><a href="activity_log.php"><i class="fas fa-history"></i> Activity</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li class="user-profile">
                    <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    
    <main class="container">
        <div class="dashboard-header">
            <div>
                <h1><i class="fas fa-chart-pie"></i> Admin Dashboard</h1>
                <p>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="manage_requests.php" class="btn btn-primary">
                    <i class="fas fa-tasks"></i> Manage Requests
                </a>
                <?php if ($pending_users > 0): ?>
                    <a href="manage_users.php?status=pending" class="btn btn-warning">
                        <i class="fas fa-user-clock"></i> Pending Users (<?php echo $pending_users; ?>)
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="dashboard-stats">
            <div class="stat-card bg-primary">
                <div class="stat-icon"><i class="fas fa-tasks"></i></div>
                <h3><?php echo $stats['total'] ?? 0; ?></h3>
                <div class="stat-label">Total Requests</div>
            </div>
            <div class="stat-card bg-warning">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <h3><?php echo $stats['pending'] ?? 0; ?></h3>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card bg-info">
                <div class="stat-icon"><i class="fas fa-spinner"></i></div>
                <h3><?php echo $stats['in_progress'] ?? 0; ?></h3>
                <div class="stat-label">In Progress</div>
            </div>
            <div class="stat-card bg-success">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <h3><?php echo $stats['resolved'] ?? 0; ?></h3>
                <div class="stat-label">Resolved</div>
            </div>
            <div class="stat-card bg-danger">
                <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                <h3><?php echo $stats['rejected'] ?? 0; ?></h3>
                <div class="stat-label">Rejected</div>
            </div>
            <div class="stat-card bg-secondary">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <h3><?php echo getTotalUsers(); ?></h3>
                <div class="stat-label">Total Users</div>
            </div>
        </div>
        
        <!-- Category Statistics -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
            <div class="card">
                <div class="section-title"><i class="fas fa-tags"></i> Request Categories</div>
                <?php if (empty($category_stats)): ?>
                    <p>No categories found</p>
                <?php else: ?>
                    <?php foreach ($category_stats as $cat): ?>
                        <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f3f4f6;">
                            <span>
                                <i class="fas fa-circle" style="color: <?php echo $cat['color']; ?>; font-size: 10px;"></i>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </span>
                            <span class="badge badge-primary"><?php echo $cat['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="card">
                <div class="section-title"><i class="fas fa-history"></i> Recent Activity</div>
                <?php if (empty($recent_activity)): ?>
                    <p>No recent activity</p>
                <?php else: ?>
                    <ul class="activity-list">
                        <?php foreach ($recent_activity as $activity): ?>
                            <li>
                                <div>
                                    <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong>
                                    <span style="color: #6c757d; font-size: 0.9rem;"><?php echo htmlspecialchars($activity['action']); ?></span>
                                </div>
                                <span class="activity-time"><?php echo date('M d, Y h:i A', strtotime($activity['created_at'])); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 12px; display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
            <a href="manage_requests.php" class="btn btn-primary">
                <i class="fas fa-tasks"></i> View All Requests
            </a>
            <a href="manage_users.php" class="btn btn-info">
                <i class="fas fa-users"></i> Manage Users
            </a>
            <a href="register_admin.php" class="btn btn-danger">
                <i class="fas fa-user-shield"></i> Create Admin
            </a>
            <a href="reports.php" class="btn btn-success">
                <i class="fas fa-file-alt"></i> Generate Reports
            </a>
            <a href="activity_log.php" class="btn btn-secondary">
                <i class="fas fa-history"></i> View Activity Log
            </a>
            <a href="../dashboard.php" class="btn btn-outline">
                <i class="fas fa-user"></i> User Dashboard
            </a>
        </div>
    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> ICT Service Portal - Admin Panel</p>
        </div>
    </footer>
    
    <script src="../assets/js/script.js"></script>
</body>
</html>