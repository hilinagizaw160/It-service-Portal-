<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
checkAdmin();
include __DIR__ . '/../includes/header.php';
?>
<div class="card" style="max-width:800px;margin:2rem auto;padding:2rem;">
    <h2><i class="fas fa-cog"></i> System Settings</h2>
    <p style="color:#64748b;">This page is reserved for future configuration options (email settings, site name, etc.).</p>
    <a href="admin_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Admin Dashboard</a>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
