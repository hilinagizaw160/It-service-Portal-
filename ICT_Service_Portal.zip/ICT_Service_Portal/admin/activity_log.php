<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
checkAdmin();

// Get filter parameters
$filter_action = isset($_GET['action']) ? sanitizeInput($_GET['action']) : '';
$filter_user = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;

// Build query
$sql = "SELECT a.*, u.full_name, u.username 
        FROM activity_logs a 
        JOIN users u ON a.user_id = u.id 
        WHERE 1=1";
$params = [];

if ($filter_action) {
    $sql .= " AND a.action LIKE ?";
    $params[] = '%' . $filter_action . '%';
}

if ($filter_user) {
    $sql .= " AND a.user_id = ?";
    $params[] = $filter_user;
}

$sql .= " ORDER BY a.created_at DESC LIMIT ?";
$params[] = $limit;

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $activities = $stmt->fetchAll();
} catch (PDOException $e) {
    $activities = [];
}

// Get all users for filter
try {
    $stmt = $conn->query("SELECT id, full_name FROM users ORDER BY full_name");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

// Get unique actions for filter
try {
    $stmt = $conn->query("SELECT DISTINCT action FROM activity_logs ORDER BY action");
    $actions = $stmt->fetchAll();
} catch (PDOException $e) {
    $actions = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log - ICT Service Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar admin-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <a href="admin_dashboard.php">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Panel</span>
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="admin_dashboard.php"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                <li><a href="manage_requests.php"><i class="fas fa-tasks"></i> Requests</a></li>
                <li><a href="manage_users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="activity_log.php" class="active"><i class="fas fa-history"></i> Activity</a></li>
                <li class="user-profile">
                    <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    
    <main class="container">
        <div class="dashboard-header">
            <div>
                <h1><i class="fas fa-history"></i> Activity Log</h1>
                <p>View all system activities and user actions</p>
            </div>
            <a href="admin_dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
        
        <!-- Filters -->
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem;">
            <form method="GET" action="" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 150px;">
                    <label for="action" style="font-size: 0.8rem;">Action</label>
                    <select name="action" id="action" class="form-control">
                        <option value="">All Actions</option>
                        <?php foreach ($actions as $action): ?>
                            <option value="<?php echo htmlspecialchars($action['action']); ?>" <?php echo $filter_action === $action['action'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($action['action']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 150px;">
                    <label for="user_id" style="font-size: 0.8rem;">User</label>
                    <select name="user_id" id="user_id" class="form-control">
                        <option value="0">All Users</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?php echo $user['id']; ?>" <?php echo $filter_user === $user['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($user['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0; min-width: 100px;">
                    <label for="limit" style="font-size: 0.8rem;">Limit</label>
                    <select name="limit" id="limit" class="form-control">
                        <option value="20" <?php echo $limit === 20 ? 'selected' : ''; ?>>20</option>
                        <option value="50" <?php echo $limit === 50 ? 'selected' : ''; ?>>50</option>
                        <option value="100" <?php echo $limit === 100 ? 'selected' : ''; ?>>100</option>
                        <option value="200" <?php echo $limit === 200 ? 'selected' : ''; ?>>200</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <a href="activity_log.php" class="btn btn-outline">
                    <i class="fas fa-undo"></i> Reset
                </a>
            </form>
        </div>
        
        <!-- Results -->
        <?php if (empty($activities)): ?>
            <div class="empty-state">
                <i class="fas fa-history" style="font-size: 3rem;"></i>
                <h3>No Activities Found</h3>
                <p>There are no activity records matching your criteria.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>IP Address</th>
                            <th>Date/Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($activities as $activity): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong>
                                    <br>
                                    <small style="color: #6c757d;">@<?php echo htmlspecialchars($activity['username']); ?></small>
                                </td>
                                <td>
                                    <span class="badge badge-primary"><?php echo htmlspecialchars($activity['action']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($activity['description'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($activity['ip_address'] ?? 'N/A'); ?></td>
                                <td><?php echo date('M d, Y h:i A', strtotime($activity['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div style="margin-top: 1rem; text-align: center; color: #6c757d; font-size: 0.9rem;">
                Showing <?php echo count($activities); ?> records
            </div>
        <?php endif; ?>
    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> ICT Service Portal - Admin Panel</p>
        </div>
    </footer>
    
    <script src="../assets/js/script.js"></script>
</body>
</html>