 <?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
checkAdmin();

$report_type = isset($_GET['type']) ? sanitizeInput($_GET['type']) : 'overview';
$date_from = isset($_GET['date_from']) ? sanitizeInput($_GET['date_from']) : date('Y-m-01');
$date_to = isset($_GET['date_to']) ? sanitizeInput($_GET['date_to']) : date('Y-m-d');

$report_data = [];
$error = null;

try {
    if ($report_type === 'overview') {
        // Total requests
        $stmt = $conn->query("SELECT COUNT(*) as total FROM service_requests");
        $report_data['total_requests'] = $stmt->fetch()['total'];
        
        // Requests by status
        $stmt = $conn->query("SELECT status, COUNT(*) as count FROM service_requests GROUP BY status");
        $report_data['status_counts'] = $stmt->fetchAll();
        
        // Requests by priority
        $stmt = $conn->query("SELECT priority, COUNT(*) as count FROM service_requests GROUP BY priority");
        $report_data['priority_counts'] = $stmt->fetchAll();
        
        // Requests by category
        $stmt = $conn->query("
            SELECT c.name, c.color, COUNT(r.id) as count 
            FROM request_categories c 
            LEFT JOIN service_requests r ON c.id = r.category_id 
            GROUP BY c.id
        ");
        $report_data['category_counts'] = $stmt->fetchAll();
        
        // Monthly requests
        $stmt = $conn->query("
            SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
            FROM service_requests 
            GROUP BY month 
            ORDER BY month DESC 
            LIMIT 12
        ");
        $report_data['monthly_counts'] = $stmt->fetchAll();
        
        // Total users
        $stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
        $report_data['total_users'] = $stmt->fetch()['total'];
        
        // New users this month
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM users 
            WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) 
            AND YEAR(created_at) = YEAR(CURRENT_DATE())
        ");
        $report_data['new_users'] = $stmt->fetch()['count'];
        
        // Average resolution time
        $stmt = $conn->query("
            SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, resolved_at)) as avg_hours 
            FROM service_requests 
            WHERE resolved_at IS NOT NULL
        ");
        $avg = $stmt->fetch();
        $report_data['avg_resolution_time'] = $avg['avg_hours'] ? round($avg['avg_hours'], 1) : 0;
        
    } else if ($report_type === 'users') {
        $stmt = $conn->query("
            SELECT u.id, u.username, u.full_name, u.email, u.department, 
                   COUNT(r.id) as request_count,
                   SUM(CASE WHEN r.status = 'resolved' THEN 1 ELSE 0 END) as resolved_count,
                   u.created_at
            FROM users u
            LEFT JOIN service_requests r ON u.id = r.user_id
            WHERE u.role = 'user'
            GROUP BY u.id
            ORDER BY request_count DESC
        ");
        $report_data['user_activity'] = $stmt->fetchAll();
        
    } else if ($report_type === 'performance') {
        $stmt = $conn->query("
            SELECT u.id, u.full_name, 
                   COUNT(r.id) as assigned_count,
                   SUM(CASE WHEN r.status = 'resolved' THEN 1 ELSE 0 END) as resolved_count,
                   AVG(TIMESTAMPDIFF(HOUR, r.created_at, r.resolved_at)) as avg_resolution_hours
            FROM users u
            LEFT JOIN service_requests r ON u.id = r.assigned_to
            WHERE u.role IN ('admin', 'super_admin')
            GROUP BY u.id
            ORDER BY resolved_count DESC
        ");
        $report_data['performance'] = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    $error = 'Failed to generate report: ' . $e->getMessage();
}

// Helper function to get status color
function getStatusColor($status) {
    $colors = [
        'pending' => '#F59E0B',
        'approved' => '#3B82F6',
        'in_progress' => '#8B5CF6',
        'resolved' => '#22C55E',
        'closed' => '#6B7280',
        'rejected' => '#EF4444'
    ];
    return $colors[$status] ?? '#6B7280';
}

// Helper function to get priority color
function getPriorityColor($priority) {
    $colors = [
        'low' => '#22C55E',
        'medium' => '#F59E0B',
        'high' => '#EF4444',
        'critical' => '#DC2626'
    ];
    return $colors[$priority] ?? '#6B7280';
}

// Helper function to calculate percentage
function calculatePercentage($count, $total) {
    if ($total > 0) {
        return round(($count / $total) * 100);
    }
    return 0;
}

// Helper function to get rate badge class
function getRateBadgeClass($rate) {
    if ($rate >= 80) return 'badge-success';
    if ($rate >= 60) return 'badge-warning';
    return 'badge-danger';
}
?>