<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mail.php';
checkAdmin();

// ============================================
// APPROVE USER
// ============================================
if (isset($_GET['approve'])) {
    $user_id = (int)$_GET['approve'];
    
    try {
        $stmt = $conn->prepare("UPDATE users SET status = 'active', email_verified = 1 WHERE id = ?");
        $stmt->execute([$user_id]);
        
        // Get user info
        $user = getUserById($user_id);
        
        // Send approval email
        $email_body = getAdminApprovalEmail($user);
        sendEmail($user['email'], 'Your Account Has Been Approved', $email_body);
        
        // Add notification
        addNotification(
            $user_id,
            'account_approved',
            'Account Approved',
            'Your account has been approved by the administrator. You can now login.',
            SITE_URL . 'login.php'
        );
        
        // Log activity
        logActivity($_SESSION['user_id'], 'user_approved', "Approved user: {$user['username']}");
        
        setFlashMessage('success', '✅ User approved successfully!');
    } catch (PDOException $e) {
        setFlashMessage('danger', '❌ Failed to approve user: ' . $e->getMessage());
    }
    header('Location: manage_users.php');
    exit();
}

// ============================================
// REJECT USER
// ============================================
if (isset($_GET['reject'])) {
    $user_id = (int)$_GET['reject'];
    
    try {
        $stmt = $conn->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$user_id]);
        
        // Log activity
        logActivity($_SESSION['user_id'], 'user_rejected', "Rejected user ID: {$user_id}");
        
        setFlashMessage('warning', '⚠️ User rejected successfully!');
    } catch (PDOException $e) {
        setFlashMessage('danger', '❌ Failed to reject user: ' . $e->getMessage());
    }
    header('Location: manage_users.php');
    exit();
}

// ============================================
// DELETE USER
// ============================================
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    
    if ($user_id == $_SESSION['user_id']) {
        setFlashMessage('danger', '❌ You cannot delete your own account!');
    } else {
        try {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            logActivity($_SESSION['user_id'], 'user_deleted', "Deleted user ID: {$user_id}");
            setFlashMessage('success', '✅ User deleted successfully!');
        } catch (PDOException $e) {
            setFlashMessage('danger', '❌ Failed to delete user: ' . $e->getMessage());
        }
    }
    header('Location: manage_users.php');
    exit();
}

// ============================================
// UPDATE ROLE
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
    $user_id = (int)$_POST['user_id'];
    $role = sanitizeInput($_POST['role']);
    
    if ($user_id == $_SESSION['user_id']) {
        setFlashMessage('danger', '❌ You cannot change your own role!');
    } else {
        try {
            $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$role, $user_id]);
            
            logActivity($_SESSION['user_id'], 'user_role_changed', "Changed user {$user_id} role to {$role}");
            setFlashMessage('success', '✅ User role updated successfully!');
        } catch (PDOException $e) {
            setFlashMessage('danger', '❌ Failed to update role: ' . $e->getMessage());
        }
    }
    header('Location: manage_users.php');
    exit();
}

// ============================================
// GET USERS
// ============================================
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$sql = "SELECT * FROM users ORDER BY created_at DESC";
if ($status_filter && in_array($status_filter, ['active', 'inactive', 'pending'])) {
    $sql = "SELECT * FROM users WHERE status = '{$status_filter}' ORDER BY created_at DESC";
}

try {
    $stmt = $conn->query($sql);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

// Get pending count
try {
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'pending'");
    $pending_count = $stmt->fetch()['count'];
} catch (PDOException $e) {
    $pending_count = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - ICT Service Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar admin-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <a href="admin_dashboard.php">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Panel</span>
                </a>
            </div>
            <ul class="nav-menu">
                <li><a href="admin_dashboard.php"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                <li><a href="manage_requests.php"><i class="fas fa-tasks"></i> Requests</a></li>
                <li><a href="manage_users.php" class="active"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="register_admin.php"><i class="fas fa-user-plus"></i> Create Admin</a></li>
                <li class="user-profile">
                    <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    
    <main class="container">
        <div class="dashboard-header">
            <div>
                <h1><i class="fas fa-users"></i> Manage Users</h1>
                <p>View and manage all registered users</p>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <?php if ($pending_count > 0): ?>
                    <a href="?status=pending" class="btn btn-warning">
                        <i class="fas fa-user-clock"></i> Pending (<?php echo $pending_count; ?>)
                    </a>
                <?php endif; ?>
                <a href="register_admin.php" class="btn btn-danger">
                    <i class="fas fa-user-shield"></i> Create Admin
                </a>
                <a href="../register.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> New User
                </a>
                <a href="admin_dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        
        <!-- Filter -->
        <div style="margin-bottom: 1.5rem; display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="manage_users.php" class="btn btn-sm <?php echo !$status_filter ? 'btn-primary' : 'btn-outline'; ?>">All</a>
            <a href="?status=active" class="btn btn-sm <?php echo $status_filter === 'active' ? 'btn-success' : 'btn-outline'; ?>">Active</a>
            <a href="?status=pending" class="btn btn-sm <?php echo $status_filter === 'pending' ? 'btn-warning' : 'btn-outline'; ?>">Pending</a>
            <a href="?status=inactive" class="btn btn-sm <?php echo $status_filter === 'inactive' ? 'btn-danger' : 'btn-outline'; ?>">Inactive</a>
        </div>
        
        <!-- Flash Messages -->
        <?php $flash = getFlashMessage(); if ($flash): ?>
            <div class="alert alert-<?php echo $flash['type']; ?> alert-dismissible">
                <?php echo $flash['message']; ?>
                <button class="alert-close" onclick="this.parentElement.style.display='none'">&times;</button>
            </div>
        <?php endif; ?>
        
        <div class="requests-section">
            <div class="section-header">
                <h2><i class="fas fa-list"></i> All Users</h2>
                <span class="badge badge-primary"><?php echo count($users); ?> Total</span>
            </div>
            
            <?php if (empty($users)): ?>
                <div class="empty-state">
                    <i class="fas fa-users-slash"></i>
                    <h3>No Users</h3>
                    <p>There are no registered users in the system.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Department</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><span class="badge badge-secondary">#<?php echo $user['id']; ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['department'] ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <span class="badge badge-danger"><i class="fas fa-user-shield"></i> Admin</span>
                                        <?php elseif ($user['role'] === 'super_admin'): ?>
                                            <span class="badge badge-danger"><i class="fas fa-crown"></i> Super Admin</span>
                                        <?php else: ?>
                                            <span class="badge badge-info"><i class="fas fa-user"></i> User</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($user['status'] === 'active'): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php elseif ($user['status'] === 'pending'): ?>
                                            <span class="badge badge-warning">Pending</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                            <?php if ($user['status'] === 'pending'): ?>
                                                <a href="?approve=<?php echo $user['id']; ?>" class="btn btn-sm btn-success" title="Approve">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <a href="?reject=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" title="Reject" onclick="return confirm('Reject this user?')">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                <form method="POST" action="" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <select name="role" onchange="this.form.submit()" class="form-control form-control-sm" style="width: auto; padding: 2px 8px;">
                                                        <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                                                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                                        <option value="super_admin" <?php echo $user['role'] === 'super_admin' ? 'selected' : ''; ?>>Super</option>
                                                    </select>
                                                    <input type="hidden" name="update_role" value="1">
                                                </form>
                                                <a href="?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="badge badge-secondary"><i class="fas fa-check"></i> You</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo date('Y'); ?> ICT Service Portal - Admin Panel</p>
        </div>
    </footer>
    
    <script src="../assets/js/script.js"></script>
</body>
</html>