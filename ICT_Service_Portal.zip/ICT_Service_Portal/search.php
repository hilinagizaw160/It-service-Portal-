<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
checkLogin();

$search_query = isset($_GET['q']) ? sanitizeInput($_GET['q']) : '';
$results = [];
$request_results = [];
$user_results = [];

if (!empty($search_query) && strlen($search_query) >= 2) {
    try {
        // Search requests
        $stmt = $conn->prepare("
            SELECT r.*, u.full_name as user_name 
            FROM service_requests r 
            JOIN users u ON r.user_id = u.id 
            WHERE r.title LIKE ? OR r.description LIKE ? OR r.request_type LIKE ?
            ORDER BY r.created_at DESC
            LIMIT 20
        ");
        $search_term = '%' . $search_query . '%';
        $stmt->execute([$search_term, $search_term, $search_term]);
        $request_results = $stmt->fetchAll();
        
        // Search users (admin only)
        if (isAdmin()) {
            $stmt = $conn->prepare("
                SELECT id, username, full_name, email, department, role, status 
                FROM users 
                WHERE username LIKE ? OR full_name LIKE ? OR email LIKE ?
                LIMIT 10
            ");
            $stmt->execute([$search_term, $search_term, $search_term]);
            $user_results = $stmt->fetchAll();
        }
    } catch (PDOException $e) {
        // Handle error
    }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="dashboard-page">
    <div class="dashboard-header">
        <h1><i class="fas fa-search"></i> Search</h1>
        <a href="dashboard.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>
    
    <div class="search-box" style="max-width: 100%; margin-bottom: 2rem;">
        <form method="GET" action="" style="display: flex; gap: 0.5rem; width: 100%;">
            <input type="text" name="q" placeholder="Search for requests, users..." value="<?php echo htmlspecialchars($search_query); ?>" style="flex: 1; padding: 0.7rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem;">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i> Search
            </button>
        </form>
        <?php if (!empty($search_query)): ?>
            <small style="color: #6c757d;">Search results for: <strong>"<?php echo htmlspecialchars($search_query); ?>"</strong></small>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($search_query) && strlen($search_query) >= 2): ?>
        
        <?php if (empty($request_results) && empty($user_results)): ?>
            <div class="empty-state">
                <i class="fas fa-search" style="font-size: 3rem;"></i>
                <h3>No Results Found</h3>
                <p>No results found for "<?php echo htmlspecialchars($search_query); ?>"</p>
            </div>
        <?php endif; ?>
        
        <!-- Request Results -->
        <?php if (!empty($request_results)): ?>
            <div class="requests-section" style="margin-bottom: 2rem;">
                <div class="section-header">
                    <h2><i class="fas fa-tasks"></i> Requests (<?php echo count($request_results); ?>)</h2>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($request_results as $request): ?>
                                <tr>
                                    <td><span class="badge badge-secondary">#<?php echo $request['id']; ?></span></td>
                                    <td><?php echo htmlspecialchars($request['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['title']); ?></td>
                                    <td><?php echo htmlspecialchars($request['request_type']); ?></td>
                                    <td>
                                        <span class="badge badge-status-<?php echo $request['status']; ?>">
                                            <?php echo str_replace('_', ' ', ucfirst($request['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                    <td>
                                        <a href="view_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- User Results (Admin only) -->
        <?php if (isAdmin() && !empty($user_results)): ?>
            <div class="requests-section">
                <div class="section-header">
                    <h2><i class="fas fa-users"></i> Users (<?php echo count($user_results); ?>)</h2>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Department</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($user_results as $user): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['department'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge <?php echo $user['role'] === 'admin' ? 'badge-danger' : 'badge-info'; ?>">
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $user['status'] === 'active' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="admin/manage_users.php" class="btn btn-sm btn-info">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        
    <?php elseif (!empty($search_query) && strlen($search_query) < 2): ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i> Please enter at least 2 characters to search.
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-search" style="font-size: 3rem;"></i>
            <h3>Search for Something</h3>
            <p>Enter a keyword to search for requests or users.</p>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>