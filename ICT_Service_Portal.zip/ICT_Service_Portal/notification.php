<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// Mark all as read
if (isset($_GET['mark_all_read'])) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$user_id]);
    header('Location: notification.php');
    exit();
}

// Mark single as read
if (isset($_GET['read']) && is_numeric($_GET['read'])) {
    $notification_id = (int)$_GET['read'];
    markNotificationAsRead($notification_id);
    header('Location: notification.php');
    exit();
}

// Get all notifications
try {
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    $notifications = [];
}

// Get counts
$unread_count = 0;
foreach ($notifications as $n) {
    if (!$n['is_read']) $unread_count++;
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="dashboard-page">
    <div class="dashboard-header">
        <div>
            <h1><i class="fas fa-bell"></i> Notifications</h1>
            <p>You have <?php echo $unread_count; ?> unread notification(s)</p>
        </div>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <?php if ($unread_count > 0): ?>
                <a href="?mark_all_read=1" class="btn btn-primary">
                    <i class="fas fa-check-double"></i> Mark All as Read
                </a>
            <?php endif; ?>
            <a href="dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
    
    <?php if (empty($notifications)): ?>
        <div class="empty-state">
            <i class="fas fa-bell-slash" style="font-size: 3rem;"></i>
            <h3>No Notifications</h3>
            <p>You don't have any notifications yet.</p>
        </div>
    <?php else: ?>
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden;">
            <?php foreach ($notifications as $notification): ?>
                <div style="padding: 1rem 1.5rem; border-bottom: 1px solid #f3f4f6; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; <?php echo !$notification['is_read'] ? 'background: #f0f4ff; border-left: 4px solid #4F46E5;' : ''; ?>">
                    <div>
                        <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                            <strong><?php echo htmlspecialchars($notification['title']); ?></strong>
                            <?php if (!$notification['is_read']): ?>
                                <span class="badge badge-primary">New</span>
                            <?php endif; ?>
                        </div>
                        <p style="margin: 0.3rem 0 0 0; color: #4b5563;"><?php echo htmlspecialchars($notification['message']); ?></p>
                        <small style="color: #6c757d;"><?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?></small>
                    </div>
                    <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                        <?php if (!$notification['is_read']): ?>
                            <a href="?read=<?php echo $notification['id']; ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-check"></i> Read
                            </a>
                        <?php endif; ?>
                        <?php if ($notification['link']): ?>
                            <a href="<?php echo $notification['link']; ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-arrow-right"></i> View
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>