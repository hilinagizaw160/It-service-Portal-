<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
checkLogin();
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:800px;margin:2rem auto;padding:2rem;text-align:center;">
    <i class="fas fa-comments" style="font-size:3rem;color:#4F46E5;margin-bottom:1rem;"></i>
    <h2>Live Chat</h2>
    <p style="color:#64748b;margin:1rem 0;">Real-time chat support is coming soon.</p>
    <p>For urgent issues please submit a <a href="request.php">service request</a> or contact the ICT team.</p>
    <a href="dashboard.php" class="btn btn-primary" style="margin-top:1.5rem;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
