<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

// Get statistics for homepage
try {
    $stmt = $conn->query("SELECT COUNT(*) as total FROM service_requests");
    $total_requests = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COUNT(*) as total FROM service_requests WHERE status = 'resolved'");
    $resolved_requests = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user' AND status = 'active'");
    $active_users = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $total_requests = $resolved_requests = $active_users = 0;
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="hero-section">
    <div class="hero-content">
        <div class="hero-badge">
            <span class="badge badge-primary"><i class="fas fa-rocket"></i> New System</span>
        </div>
        <h1>Welcome to <br><span style="color: #818CF8;">ICT Service Portal</span></h1>
        <p>Submit and track your ICT service requests efficiently. Get technical support for hardware, software, networking, and more.</p>
        
        <?php if (!isLoggedIn()): ?>
            <div class="hero-buttons">
                <a href="register.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-user-plus"></i> Get Started
                </a>
                <a href="login.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
            </div>
        <?php else: ?>
            <div class="hero-buttons">
                <a href="dashboard.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-chart-pie"></i> Go to Dashboard
                </a>
                <a href="request.php" class="btn btn-success btn-lg">
                    <i class="fas fa-plus-circle"></i> Submit Request
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="margin-bottom: 2rem;">
    <div class="stat-card">
        <div class="stat-icon bg-primary"><i class="fas fa-tasks"></i></div>
        <div class="stat-info">
            <h3><?php echo $total_requests; ?></h3>
            <p>Total Requests</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-success"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info">
            <h3><?php echo $resolved_requests; ?></h3>
            <p>Resolved</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-info"><i class="fas fa-users"></i></div>
        <div class="stat-info">
            <h3><?php echo $active_users; ?></h3>
            <p>Active Users</p>
        </div>
    </div>
</div>

<!-- Features -->
<div class="features-section">
    <h2>How It Works</h2>
    <p style="color: #6c757d; margin-bottom: 2rem;">Simple process to get your ICT issues resolved quickly</p>
    
    <div class="features-grid">
        <div class="feature-card">
            <div class="feature-icon"><i class="fas fa-file-signature"></i></div>
            <h3>Submit Request</h3>
            <p>Fill out the service request form with details about your ICT issue</p>
            <div class="feature-step"><span class="badge badge-primary">Step 1</span></div>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><i class="fas fa-clock"></i></div>
            <h3>Track Progress</h3>
            <p>Monitor the status of your requests in real-time from your dashboard</p>
            <div class="feature-step"><span class="badge badge-primary">Step 2</span></div>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><i class="fas fa-check-circle"></i></div>
            <h3>Get Resolution</h3>
            <p>Receive updates and resolution for your ICT needs with priority support</p>
            <div class="feature-step"><span class="badge badge-primary">Step 3</span></div>
        </div>
    </div>
</div>

<!-- CTA -->
<div style="background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); color: white; padding: 3rem 2rem; border-radius: 12px; text-align: center; margin-top: 2rem;">
    <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">Ready to Submit a Request?</h2>
    <p style="font-size: 1.1rem; opacity: 0.9; margin-bottom: 1.5rem;">Join users getting their ICT issues resolved quickly</p>
    <a href="<?php echo isLoggedIn() ? 'request.php' : 'register.php'; ?>" class="btn btn-light btn-lg">
        <i class="fas fa-arrow-right"></i> Get Started Now
    </a>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>