<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

if (function_exists('logout')) {
    logout();
} else {
    session_destroy();
    header('Location: login.php');
    exit();
}
