<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$user = getCurrentUser();

// Get user requests
$requests = getUserRequests($user_id, 10);
$stats = getRequestStats($user_id);

// Get notifications
$notifications = getUnreadNotifications($user_id);
$notification_count = count($notifications);

// Get recent activity
try {
    $stmt = $conn->prepare("SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $recent_activity = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_activity = [];
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="dashboard-page">
    <div class="dashboard-header">
        <div>
            <h1><i class="fas fa-chart-pie"></i> Dashboard</h1>
            <p class="welcome-text">Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
        </div>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="request.php" class="btn btn-primary btn-lg">
                <i class="fas fa-plus-circle"></i> New Request
            </a>
            <?php if ($notification_count > 0): ?>
                <a href="notification.php" class="btn btn-info">
                    <i class="fas fa-bell"></i> Notifications (<?php echo $notification_count; ?>)
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon bg-primary"><i class="fas fa-tasks"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['total'] ?? 0; ?></h3>
                <p>Total Requests</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-warning"><i class="fas fa-clock"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['pending'] ?? 0; ?></h3>
                <p>Pending</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-info"><i class="fas fa-spinner"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['in_progress'] ?? 0; ?></h3>
                <p>In Progress</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon bg-success"><i class="fas fa-check-circle"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['resolved'] ?? 0; ?></h3>
                <p>Resolved</p>
            </div>
        </div>
    </div>
    
    <!-- Recent Requests -->
    <div class="requests-section">
        <div class="section-header">
            <h2><i class="fas fa-list"></i> My Recent Requests</h2>
            <a href="dashboard.php?view=all" class="btn btn-outline">View All</a>
        </div>
        
        <?php if (empty($requests)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>No Requests Yet</h3>
                <p>You haven't submitted any service requests yet.</p>
                <a href="request.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> Submit Your First Request
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><span class="badge badge-secondary">#<?php echo $request['id']; ?></span></td>
                                <td><?php echo htmlspecialchars($request['title']); ?></td>
                                <td><?php echo htmlspecialchars($request['category_name'] ?? $request['request_type']); ?></td>
                                <td>
                                    <span class="badge badge-priority-<?php echo $request['priority']; ?>">
                                        <?php echo ucfirst($request['priority']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-status-<?php echo $request['status']; ?>">
                                        <?php echo str_replace('_', ' ', ucfirst($request['status'])); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                <td>
                                    <a href="view_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Recent Activity -->
    <?php if (!empty($recent_activity)): ?>
    <div style="margin-top: 2rem; background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h3><i class="fas fa-history"></i> Recent Activity</h3>
        <ul style="list-style: none; padding: 0; margin-top: 1rem;">
            <?php foreach ($recent_activity as $activity): ?>
                <li style="padding: 8px 0; border-bottom: 1px solid #f3f4f6; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
                    <span>
                        <i class="fas fa-circle" style="color: #4F46E5; font-size: 8px;"></i>
                        <?php echo htmlspecialchars($activity['action']); ?>
                        <?php if ($activity['description']): ?>
                            <span style="color: #6c757d; font-size: 0.9rem;">- <?php echo htmlspecialchars($activity['description']); ?></span>
                        <?php endif; ?>
                    </span>
                    <span style="color: #6c757d; font-size: 0.8rem;"><?php echo date('M d, Y h:i A', strtotime($activity['created_at'])); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>