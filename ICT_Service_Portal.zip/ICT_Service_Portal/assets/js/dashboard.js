// Dashboard specific scripts (charts can be added later with Chart.js)
console.log('Dashboard JS loaded');
