<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mail.php';
require_once __DIR__ . '/includes/upload.php';
checkLogin();

$error = '';
$success = '';

// Get categories
try {
    $stmt = $conn->query("SELECT * FROM request_categories WHERE is_active = 1 ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $request_type = sanitizeInput($_POST['request_type'] ?? '');
    $title = sanitizeInput($_POST['title'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $priority = sanitizeInput($_POST['priority'] ?? 'medium');
    
    $errors = [];
    
    if (empty($category_id) && empty($request_type)) {
        $errors[] = 'Please select a category or request type';
    }
    if (empty($title)) {
        $errors[] = 'Please enter a title';
    }
    if (empty($description)) {
        $errors[] = 'Please enter a description';
    }
    if (strlen($description) < 20) {
        $errors[] = 'Description must be at least 20 characters';
    }
    
    // Handle file upload
    $attachment = null;
    $attachment_name = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadFile($_FILES['attachment']);
        if ($upload_result['success']) {
            $attachment = $upload_result['filename'];
            $attachment_name = $_FILES['attachment']['name'];
        } else {
            $errors[] = 'File upload error: ' . $upload_result['error'];
        }
    }
    
    if (empty($errors)) {
        $data = [
            'user_id' => $_SESSION['user_id'],
            'category_id' => $category_id,
            'request_type' => $request_type ?: 'Other',
            'title' => $title,
            'description' => $description,
            'priority' => $priority,
            'attachment' => $attachment,
            'attachment_name' => $attachment_name
        ];
        
        if (createRequest($data)) {
            $request_id = $conn->lastInsertId();
            
            // Log activity
            logActivity($_SESSION['user_id'], 'request_created', "Created request #{$request_id}: {$title}");
            
            // Get user info
            $user = getUserById($_SESSION['user_id']);
            $request = getRequestById($request_id);
            
            // Send email
            $email_body = getRequestCreatedEmail($request, $user);
            sendEmail($user['email'], "Request #{$request_id} Created", $email_body);
            
            // Notify admins
            $stmt = $conn->query("SELECT id FROM users WHERE role IN ('admin', 'super_admin')");
            $admins = $stmt->fetchAll();
            foreach ($admins as $admin) {
                addNotification(
                    $admin['id'],
                    'new_request',
                    "New Request #{$request_id}",
                    "User {$user['full_name']} created a new request: {$title}",
                    SITE_URL . "admin/manage_requests.php"
                );
            }
            
            setFlashMessage('success', '✅ Request submitted successfully! You will receive a notification when it is processed.');
            header('Location: dashboard.php');
            exit();
        } else {
            $errors[] = 'Failed to submit request. Please try again.';
        }
    }
    
    if (!empty($errors)) {
        $error = implode('<br>', $errors);
    }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="form-container">
    <div class="form-card">
        <div class="form-header">
            <i class="fas fa-plus-circle"></i>
            <h2>Submit Service Request</h2>
            <p>Fill in the details below to submit your ICT service request</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" enctype="multipart/form-data" class="request-form">
            <!-- Category -->
            <div class="form-group">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id">
                    <option value="">-- Select Category --</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>">
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small style="color: #6c757d;">Or select request type below</small>
            </div>
            
            <div class="form-group">
                <label for="request_type">Request Type</label>
                <select id="request_type" name="request_type">
                    <option value="">-- Select Type --</option>
                    <?php foreach (getRequestTypes() as $type): ?>
                        <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="title">Title *</label>
                <input type="text" id="title" name="title" placeholder="Brief title of your request" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description *</label>
                <textarea id="description" name="description" rows="6" placeholder="Detailed description of your issue..." required></textarea>
                <small class="form-text">Please provide as much detail as possible (minimum 20 characters)</small>
            </div>
            
            <div class="form-group">
                <label for="priority">Priority Level</label>
                <select id="priority" name="priority">
                    <?php foreach (getPriorityOptions() as $key => $value): ?>
                        <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="attachment">Attach File (optional)</label>
                <input type="file" id="attachment" name="attachment" class="form-control">
                <small style="color: #6c757d;">Max size: 10MB. Allowed: jpg, jpeg, png, gif, pdf, doc, docx, xls, xlsx, zip, rar</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-paper-plane"></i> Submit Request
                </button>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Cancel
                </a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>