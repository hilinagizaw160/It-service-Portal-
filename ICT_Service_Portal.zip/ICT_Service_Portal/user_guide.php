<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:900px;margin:2rem auto;padding:2rem;">
    <h1><i class="fas fa-book"></i> User Guide</h1>
    <hr>
    <h3>1. Register & Login</h3>
    <p>Create an account with a strong password. New accounts stay <strong>pending</strong> until an administrator approves them.</p>

    <h3>2. Submit a Service Request</h3>
    <p>Go to <strong>New Request</strong>, choose a category, write a clear title and description (minimum 20 characters), set priority, and optionally attach a file (max 10 MB).</p>

    <h3>3. Track Your Requests</h3>
    <p>Your Dashboard shows all requests with status badges: Pending → Approved → In Progress → Resolved / Closed.</p>

    <h3>4. Notifications</h3>
    <p>You receive notifications when the status of your request changes or when an admin leaves a comment.</p>

    <h3>5. Profile</h3>
    <p>Update your name, department, phone number, and password from the Profile page.</p>

    <h3>Need help?</h3>
    <p>Contact the ICT support team or open a new request with category “Other”.</p>

    <a href="dashboard.php" class="btn btn-primary" style="margin-top:1.5rem;"><i class="fas fa-arrow-left"></i> Back</a>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
