<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mail.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $full_name = sanitizeInput($_POST['full_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $department = sanitizeInput($_POST['department'] ?? '');
    $phone = sanitizeInput($_POST['phone'] ?? '');
    
    $errors = [];
    
    if (empty($username) || empty($email) || empty($full_name) || empty($password)) {
        $errors[] = 'Please fill in all required fields';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address';
    }
    if (strlen($username) < 3) {
        $errors[] = 'Username must be at least 3 characters';
    }
    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match';
    }
    
    $password_errors = validatePassword($password);
    if (!empty($password_errors)) {
        $errors = array_merge($errors, $password_errors);
    }
    
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->rowCount() > 0) {
                $errors[] = 'Username or email already exists';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, department, phone, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
                $result = $stmt->execute([$username, $email, $hashed_password, $full_name, $department, $phone]);
                
                if ($result) {
                    $user_id = $conn->lastInsertId();
                    logActivity($user_id, 'registration', 'User registered');
                    
                    $user = getUserById($user_id);
                    $email_body = getRegistrationEmail($user);
                    sendEmail($user['email'], 'Welcome to ICT Service Portal', $email_body);
                    
                    $stmt = $conn->query("SELECT id, email FROM users WHERE role IN ('admin', 'super_admin')");
                    $admins = $stmt->fetchAll();
                    foreach ($admins as $admin) {
                        addNotification(
                            $admin['id'],
                            'new_user',
                            'New User Registration',
                            "A new user '{$user['full_name']}' has registered and is pending approval.",
                            SITE_URL . 'admin/manage_users.php'
                        );
                    }
                    
                    setFlashMessage('success', '✅ Registration successful! Your account is pending admin approval.');
                    header('Location: login.php');
                    exit();
                } else {
                    $errors[] = 'Failed to create account';
                }
            }
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
    
    if (!empty($errors)) {
        $error = implode('<br>', $errors);
    }
}

$db_status = isset($conn) ? 'Connected ✅' : 'Not Connected ❌';
?>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <i class="fas fa-user-plus" style="font-size: 2rem; color: #4F46E5;"></i>
            <h2>Create Account</h2>
            <p style="color: #64748b;">Join ICT ICT Service Request Portal</p>
        </div>
        
        <div style="background: #f8f9fa; padding: 10px; margin-bottom: 15px; border-radius: 5px; font-size: 14px; border-left: 4px solid <?php echo strpos($db_status, 'Connected') !== false ? '#28a745' : '#dc3545'; ?>;">
            <strong>Database Status:</strong> <?php echo $db_status; ?>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username *</label>
                <input type="text" id="username" name="username" placeholder="Choose a username (min 3 characters)" required>
            </div>
            
            <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email *</label>
                <input type="email" id="email" name="email" placeholder="your@email.com" required>
            </div>
            
            <div class="form-group">
                <label for="full_name"><i class="fas fa-user-tag"></i> Full Name *</label>
                <input type="text" id="full_name" name="full_name" placeholder="John Doe" required>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="department"><i class="fas fa-building"></i> Department</label>
                    <input type="text" id="department" name="department" placeholder="IT, HR, etc.">
                </div>
                <div class="form-group">
                    <label for="phone"><i class="fas fa-phone"></i> Phone</label>
                    <input type="tel" id="phone" name="phone" placeholder="+251 9XX XXX XXX">
                </div>
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password *</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Min 8 characters with uppercase, lowercase, number, special char" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('password', this)">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <small style="display: block; margin-top: 5px; color: #6c757d;">
                    Password must contain: uppercase, lowercase, number, and special character (!@#$%^&*)
                </small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password"><i class="fas fa-check-circle"></i> Confirm Password *</label>
                <div class="password-wrapper">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('confirm_password', this)">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-user-plus"></i> Create Account
            </button>
        </form>
        
        <div class="auth-footer">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</div>

<style>
.password-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.password-wrapper input {
    width: 100%;
    padding-right: 45px;
}

.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #94a3b8;
    font-size: 1.1rem;
    padding: 5px;
    transition: color 0.3s;
}

.toggle-password:hover {
    color: #4F46E5;
}

.toggle-password:focus {
    outline: none;
}
</style>

<script>
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>