    </main><!-- end .container -->

    <footer class="site-footer">
        <div class="footer-content">
            <div class="footer-brand">
                <i class="fas fa-laptop-code"></i>
                <strong>ICT Service Portal</strong>
            </div>
            <p>&copy; <?php echo date('Y'); ?> ICT Service Portal. All rights reserved.</p>
            <p class="footer-links">
                <a href="<?php echo (strpos(dirname($_SERVER['SCRIPT_NAME']), '/admin') !== false) ? '../' : ''; ?>user_guide.php">User Guide</a>
                &nbsp;|&nbsp;
                <a href="mailto:admin@ictportal.com">Support</a>
            </p>
        </div>
    </footer>

    <script>
    // Simple mobile nav toggle already in header
    // Auto-hide flash messages after 5 seconds
    document.querySelectorAll('.alert-dismissible').forEach(function(el) {
        setTimeout(function() {
            el.style.transition = 'opacity 0.5s';
            el.style.opacity = '0';
            setTimeout(function() { el.style.display = 'none'; }, 500);
        }, 5000);
    });
    </script>
</body>
</html>
