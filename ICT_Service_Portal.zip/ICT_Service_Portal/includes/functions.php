<?php
require_once 'db.php';

// ============================================
// USER FUNCTIONS
// ============================================
function getUserById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getUserByEmail($email) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

function updateUserProfile($user_id, $data) {
    global $conn;
    $stmt = $conn->prepare("UPDATE users SET full_name = ?, department = ?, phone = ? WHERE id = ?");
    return $stmt->execute([$data['full_name'], $data['department'], $data['phone'], $user_id]);
}

function updateUserPassword($user_id, $new_password) {
    global $conn;
    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    return $stmt->execute([$hashed, $user_id]);
}

// ============================================
// REQUEST FUNCTIONS
// ============================================
function createRequest($data) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO service_requests (user_id, category_id, request_type, title, description, priority, attachment, attachment_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $data['user_id'],
        $data['category_id'] ?? null,
        $data['request_type'],
        $data['title'],
        $data['description'],
        $data['priority'] ?? 'medium',
        $data['attachment'] ?? null,
        $data['attachment_name'] ?? null
    ]);
}

function getRequestById($id) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT r.*, u.full_name as requester_name, u.email as requester_email,
               a.full_name as assignee_name, c.name as category_name, c.color as category_color
        FROM service_requests r
        LEFT JOIN users u ON r.user_id = u.id
        LEFT JOIN users a ON r.assigned_to = a.id
        LEFT JOIN request_categories c ON r.category_id = c.id
        WHERE r.id = ?
    ");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getUserRequests($user_id, $limit = null) {
    global $conn;
    $sql = "SELECT r.*, c.name as category_name FROM service_requests r 
            LEFT JOIN request_categories c ON r.category_id = c.id 
            WHERE r.user_id = ? ORDER BY r.created_at DESC";
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function getAllRequests($limit = null) {
    global $conn;
    $sql = "SELECT r.*, u.full_name as user_name, u.email as user_email, c.name as category_name 
            FROM service_requests r 
            LEFT JOIN users u ON r.user_id = u.id 
            LEFT JOIN request_categories c ON r.category_id = c.id 
            ORDER BY r.created_at DESC";
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = $conn->query($sql);
    return $stmt->fetchAll();
}

function getRequestComments($request_id) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT c.*, u.full_name, u.role, u.profile_image 
        FROM request_comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.request_id = ? 
        ORDER BY c.created_at ASC
    ");
    $stmt->execute([$request_id]);
    return $stmt->fetchAll();
}

function addRequestComment($request_id, $user_id, $comment, $attachment = null) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO request_comments (request_id, user_id, comment, attachment) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$request_id, $user_id, $comment, $attachment]);
}

function updateRequestStatus($request_id, $status, $admin_id = null) {
    global $conn;
    
    if ($status === 'resolved') {
        $stmt = $conn->prepare("UPDATE service_requests SET status = ?, resolved_at = NOW() WHERE id = ?");
        $result = $stmt->execute([$status, $request_id]);
    } elseif ($status === 'approved') {
        $stmt = $conn->prepare("UPDATE service_requests SET status = ?, approved_at = NOW(), approved_by = ? WHERE id = ?");
        $result = $stmt->execute([$status, $admin_id, $request_id]);
    } else {
        $stmt = $conn->prepare("UPDATE service_requests SET status = ? WHERE id = ?");
        $result = $stmt->execute([$status, $request_id]);
    }
    
    // Log activity
    if ($result && $admin_id) {
        logActivity($admin_id, 'request_status_update', "Updated request #{$request_id} to {$status}");
    }
    
    return $result;
}

function assignRequest($request_id, $assigned_to, $admin_id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE service_requests SET assigned_to = ? WHERE id = ?");
    $result = $stmt->execute([$assigned_to, $request_id]);
    
    if ($result) {
        logActivity($admin_id, 'request_assigned', "Assigned request #{$request_id} to user ID {$assigned_to}");
    }
    return $result;
}

function deleteRequest($request_id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM service_requests WHERE id = ?");
    return $stmt->execute([$request_id]);
}

// ============================================
// REQUEST STATISTICS
// ============================================
function getRequestStats($user_id = null) {
    global $conn;
    
    $sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved,
                SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
            FROM service_requests";
    
    if ($user_id) {
        $sql .= " WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_id]);
    } else {
        $stmt = $conn->query($sql);
    }
    
    return $stmt->fetch();
}

function getCategoryStats() {
    global $conn;
    $stmt = $conn->query("
        SELECT c.name, c.color, COUNT(r.id) as count 
        FROM request_categories c
        LEFT JOIN service_requests r ON c.id = r.category_id
        GROUP BY c.id
        ORDER BY count DESC
    ");
    return $stmt->fetchAll();
}

// ============================================
// FILE UPLOAD FUNCTIONS
// ============================================
function uploadFile($file, $target_dir = null) {
    if (!$target_dir) {
        $target_dir = UPLOAD_DIR . 'requests/';
    }
    
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Upload error: ' . $file['error']];
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'error' => 'File too large. Maximum size is ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB'];
    }
    
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS)) {
        return ['success' => false, 'error' => 'File type not allowed'];
    }
    
    $filename = sanitizeFilename($file['name']);
    $target_path = $target_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return ['success' => true, 'filename' => $filename, 'path' => $target_path];
    }
    
    return ['success' => false, 'error' => 'Failed to move uploaded file'];
}

function deleteFile($file_path) {
    if (file_exists($file_path)) {
        return unlink($file_path);
    }
    return false;
}

// ============================================
// ADMIN PERMISSIONS
// ============================================
function isSuperAdmin($user_id) {
    $user = getUserById($user_id);
    return $user && $user['role'] === 'super_admin';
}

function canManageUsers($user_id) {
    if (isSuperAdmin($user_id)) return true;
    return hasPermission($user_id, 'manage_users');
}

function canManageRequests($user_id) {
    if (isSuperAdmin($user_id)) return true;
    return hasPermission($user_id, 'manage_requests');
}

function canViewReports($user_id) {
    if (isSuperAdmin($user_id)) return true;
    return hasPermission($user_id, 'view_reports');
}

function canManageSettings($user_id) {
    if (isSuperAdmin($user_id)) return true;
    return hasPermission($user_id, 'manage_settings');
}
?><?php
/**
 * Activity logging helper
 */
function logActivity($user_id, $action, $description = '') {
    global $conn;
    if (!$conn) return false;
    try {
        $stmt = $conn->prepare(
            "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) 
             VALUES (?, ?, ?, ?, ?)"
        );
        return $stmt->execute([
            $user_id,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        ]);
    } catch (Exception $e) {
        // Silently fail – logging should never break the app
        error_log('logActivity error: ' . $e->getMessage());
        return false;
    }
}

// Simple permission helper (fallback if table is empty)
function hasPermission($user_id, $permission) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT granted FROM user_permissions WHERE user_id = ? AND permission = ? AND granted = 1");
        $stmt->execute([$user_id, $permission]);
        return (bool)$stmt->fetch();
    } catch (Exception $e) {
        return false;
    }
}

function checkDatabaseConnection() {
    global $conn;
    return isset($conn) && $conn instanceof PDO;
}

function getUnreadNotifications($user_id, $limit = 10) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
        $stmt->bindValue(2, (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

function getRequestComments($request_id) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            SELECT c.*, u.full_name, u.role 
            FROM request_comments c 
            JOIN users u ON c.user_id = u.id 
            WHERE c.request_id = ? 
            ORDER BY c.created_at ASC
        ");
        $stmt->execute([$request_id]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}
