<?php
require_once __DIR__ . '/config.php';

/**
 * Simple email templates (HTML)
 */
function getRegistrationEmail($user) {
    $name = htmlspecialchars($user['full_name'] ?? 'User');
    $email = htmlspecialchars($user['email'] ?? '');
    $username = htmlspecialchars($user['username'] ?? '');
    return "
    <!DOCTYPE html><html><head><meta charset='UTF-8'></head>
    <body style='font-family:Arial,sans-serif;background:#f4f7f9;margin:0;padding:20px;'>
    <div style='max-width:600px;margin:0 auto;background:#fff;border-radius:10px;overflow:hidden;'>
      <div style='background:#4F46E5;color:#fff;padding:20px;text-align:center;'>
        <h1 style='margin:0;'>Welcome to ICT Service Portal</h1>
      </div>
      <div style='padding:30px;'>
        <h2>Hello {$name},</h2>
        <p>Thank you for registering on our ICT Service Request Portal.</p>
        <p><strong>Email:</strong> {$email}<br><strong>Username:</strong> {$username}</p>
        <p>Your account is pending admin approval. You will be notified once it is approved.</p>
        <p style='margin-top:25px;'>
          <a href='" . SITE_URL . "login.php' style='display:inline-block;background:#4F46E5;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;'>Login</a>
        </p>
      </div>
      <div style='text-align:center;padding:15px;color:#666;font-size:12px;'>
        &copy; " . date('Y') . " ICT Service Portal
      </div>
    </div></body></html>";
}

function getRequestCreatedEmail($request, $user) {
    $name = htmlspecialchars($user['full_name'] ?? 'User');
    $title = htmlspecialchars($request['title'] ?? '');
    return "
    <!DOCTYPE html><html><head><meta charset='UTF-8'></head>
    <body style='font-family:Arial,sans-serif;background:#f4f7f9;margin:0;padding:20px;'>
    <div style='max-width:600px;margin:0 auto;background:#fff;border-radius:10px;overflow:hidden;'>
      <div style='background:#22C55E;color:#fff;padding:20px;text-align:center;'>
        <h1 style='margin:0;'>Request Submitted</h1>
      </div>
      <div style='padding:30px;'>
        <h2>Hello {$name},</h2>
        <p>Your service request has been submitted successfully.</p>
        <p><strong>Title:</strong> {$title}</p>
        <p>You can track the status from your dashboard.</p>
        <p style='margin-top:25px;'>
          <a href='" . SITE_URL . "dashboard.php' style='display:inline-block;background:#22C55E;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;'>Go to Dashboard</a>
        </p>
      </div>
      <div style='text-align:center;padding:15px;color:#666;font-size:12px;'>
        &copy; " . date('Y') . " ICT Service Portal
      </div>
    </div></body></html>";
}

function getAdminApprovalEmail($user) {
    $name = htmlspecialchars($user['full_name'] ?? 'User');
    return "
    <!DOCTYPE html><html><head><meta charset='UTF-8'></head>
    <body style='font-family:Arial,sans-serif;background:#f4f7f9;margin:0;padding:20px;'>
    <div style='max-width:600px;margin:0 auto;background:#fff;border-radius:10px;overflow:hidden;'>
      <div style='background:#4F46E5;color:#fff;padding:20px;text-align:center;'>
        <h1 style='margin:0;'>Account Approved</h1>
      </div>
      <div style='padding:30px;'>
        <h2>Hello {$name},</h2>
        <p>Your account has been approved by the administrator. You can now login and submit service requests.</p>
        <p style='margin-top:25px;'>
          <a href='" . SITE_URL . "login.php' style='display:inline-block;background:#4F46E5;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;'>Login Now</a>
        </p>
      </div>
      <div style='text-align:center;padding:15px;color:#666;font-size:12px;'>
        &copy; " . date('Y') . " ICT Service Portal
      </div>
    </div></body></html>";
}

/**
 * Send email – tries PHPMailer if available, otherwise falls back to PHP mail()
 * Returns ['success' => bool, 'message' => string]
 */
function sendEmail($to, $subject, $body, $isHTML = true) {
    // Try PHPMailer if the library is present
    $phpmailer_base = dirname(__DIR__) . '/vendor/phpmailer/src/';
    if (file_exists($phpmailer_base . 'PHPMailer.php')) {
        require_once $phpmailer_base . 'PHPMailer.php';
        require_once $phpmailer_base . 'SMTP.php';
        require_once $phpmailer_base . 'Exception.php';

        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USER;
            $mail->Password   = SMTP_PASS;
            $mail->SMTPSecure = SMTP_ENCRYPTION;
            $mail->Port       = SMTP_PORT;
            $mail->setFrom(SMTP_USER, SITE_NAME);
            $mail->addAddress($to);
            $mail->isHTML($isHTML);
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->send();
            return ['success' => true, 'message' => 'Email sent successfully'];
        } catch (Exception $e) {
            error_log('PHPMailer error: ' . $mail->ErrorInfo);
            // Fall through to native mail
        }
    }

    // Fallback: native PHP mail()
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . SITE_NAME . " <" . (defined('ADMIN_EMAIL') ? ADMIN_EMAIL : 'noreply@localhost') . ">\r\n";

    $ok = @mail($to, $subject, $body, $headers);
    if ($ok) {
        return ['success' => true, 'message' => 'Email sent (native mail)'];
    }
    return ['success' => false, 'message' => 'Email could not be sent. Check server mail configuration.'];
}
