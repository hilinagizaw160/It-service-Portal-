<?php
require_once __DIR__ . '/config.php';

/**
 * Secure file upload helper
 * Returns ['success' => true, 'filename' => ..., 'path' => ...] or ['success' => false, 'error' => ...]
 */
function uploadFile($file, $target_dir = null) {
    if (!$target_dir) {
        $target_dir = UPLOAD_DIR . 'requests/';
    }

    // Ensure directory exists
    if (!is_dir($target_dir)) {
        if (!mkdir($target_dir, 0755, true)) {
            return ['success' => false, 'error' => 'Cannot create upload directory'];
        }
    }

    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'error' => 'Invalid file parameters'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE   => 'File exceeds server limit',
            UPLOAD_ERR_FORM_SIZE  => 'File exceeds form limit',
            UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE    => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION  => 'File upload stopped by extension',
        ];
        return ['success' => false, 'error' => $messages[$file['error']] ?? 'Unknown upload error'];
    }

    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'error' => 'File too large. Maximum size is ' . (MAX_FILE_SIZE / 1024 / 1024) . ' MB'];
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS, true)) {
        return ['success' => false, 'error' => 'File type not allowed. Allowed: ' . implode(', ', ALLOWED_EXTENSIONS)];
    }

    // Extra MIME check (basic)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed_mimes = [
        'image/jpeg', 'image/png', 'image/gif',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/zip', 'application/x-rar-compressed', 'application/x-zip-compressed'
    ];
    // Soft check – some servers return different MIME for zip/rar
    // We already validated extension, so continue even if MIME is unexpected

    $safe_name = preg_replace('/[^a-zA-Z0-9._-]/', '', basename($file['name']));
    $filename  = time() . '_' . $safe_name;
    $target_path = rtrim($target_dir, '/\\') . DIRECTORY_SEPARATOR . $filename;

    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        return ['success' => false, 'error' => 'Failed to move uploaded file'];
    }

    // Set safe permissions
    chmod($target_path, 0644);

    return [
        'success'  => true,
        'filename' => $filename,
        'path'     => $target_path,
        'original' => $file['name']
    ];
}

function deleteFile($file_path) {
    if ($file_path && file_exists($file_path) && is_file($file_path)) {
        return unlink($file_path);
    }
    return false;
}
