<?php
/**
 * Activity logging helper
 */
function logActivity($user_id, $action, $description = '') {
    global $conn;
    if (!$conn) return false;
    try {
        $stmt = $conn->prepare(
            "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) 
             VALUES (?, ?, ?, ?, ?)"
        );
        return $stmt->execute([
            $user_id,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        ]);
    } catch (Exception $e) {
        // Silently fail – logging should never break the app
        error_log('logActivity error: ' . $e->getMessage());
        return false;
    }
}
