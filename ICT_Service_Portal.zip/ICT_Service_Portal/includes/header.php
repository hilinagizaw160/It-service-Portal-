<?php
// Ensure session and config are loaded
if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/config.php';
}
if (!function_exists('isLoggedIn')) {
    require_once __DIR__ . '/session.php';
}

$unread_count = 0;
if (function_exists('isLoggedIn') && isLoggedIn()) {
    try {
        if (!isset($conn)) {
            require_once __DIR__ . '/db.php';
        }
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$_SESSION['user_id']]);
        $unread_count = (int)$stmt->fetch()['count'];
    } catch (Exception $e) {
        $unread_count = 0;
    }
}

// Determine base path for assets (works from root and admin/)
$script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$is_admin = (strpos($script_dir, '/admin') !== false);
$asset_prefix = $is_admin ? '../' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo defined('SITE_NAME') ? SITE_NAME : 'ICT Service Portal'; ?></title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $asset_prefix; ?>assets/css/style.css">
    
    <style>
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #EF4444;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: 700;
            min-width: 18px;
            text-align: center;
        }
        .nav-item-with-badge {
            position: relative;
        }
        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        @media (max-width: 768px) {
            .mobile-toggle { display: block; }
            .nav-menu { display: none; flex-direction: column; width: 100%; padding: 1rem 0; }
            .nav-menu.active { display: flex; }
            .nav-menu a { width: 100%; padding: 0.6rem 1rem; }
            .user-profile { flex-direction: column; align-items: stretch; background: transparent; padding: 0; }
            .nav-item-with-badge { display: flex; align-items: center; gap: 10px; }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="<?php echo $asset_prefix; ?>index.php" class="nav-logo">
                <i class="fas fa-laptop-code"></i>
                <span>ICT Service Portal</span>
            </a>
            
            <button class="mobile-toggle" onclick="document.querySelector('.nav-menu').classList.toggle('active')">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="nav-menu">
                <?php if (function_exists('isLoggedIn') && isLoggedIn()): ?>
                    <li><a href="<?php echo $asset_prefix; ?>dashboard.php"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li><a href="<?php echo $asset_prefix; ?>request.php"><i class="fas fa-plus-circle"></i> New Request</a></li>
                    <li><a href="<?php echo $asset_prefix; ?>search.php"><i class="fas fa-search"></i> Search</a></li>
                    
                    <?php if (function_exists('isAdmin') && isAdmin()): ?>
                        <li><a href="<?php echo $asset_prefix; ?>admin/admin_dashboard.php"><i class="fas fa-user-shield"></i> Admin Panel</a></li>
                    <?php endif; ?>
                    
                    <li class="nav-item-with-badge">
                        <a href="<?php echo $asset_prefix; ?>notification.php">
                            <i class="fas fa-bell"></i> Notifications
                            <?php if ($unread_count > 0): ?>
                                <span class="notification-badge"><?php echo $unread_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li><a href="<?php echo $asset_prefix; ?>chat.php"><i class="fas fa-comments"></i> Chat</a></li>
                    
                    <li class="user-profile">
                        <div class="profile-info">
                            <i class="fas fa-user-circle"></i>
                            <span><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                        </div>
                        <a href="<?php echo $asset_prefix; ?>profile.php" class="btn btn-sm btn-outline-light">Profile</a>
                        <a href="<?php echo $asset_prefix; ?>logout.php" class="logout-btn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo $asset_prefix; ?>index.php"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="<?php echo $asset_prefix; ?>login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                    <li><a href="<?php echo $asset_prefix; ?>register.php"><i class="fas fa-user-plus"></i> Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    
    <!-- MAIN CONTENT -->
    <main class="container">
        <!-- Flash Messages -->
        <?php if (function_exists('getFlashMessage')): ?>
            <?php $flash = getFlashMessage(); ?>
            <?php if ($flash): ?>
                <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?> alert-dismissible">
                    <?php echo htmlspecialchars($flash['message']); ?>
                    <button class="alert-close" onclick="this.parentElement.style.display='none'">&times;</button>
                </div>
            <?php endif; ?>
        <?php endif; ?>
