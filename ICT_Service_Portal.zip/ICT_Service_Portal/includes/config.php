<?php
// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'service_portal');

// ============================================
// APPLICATION CONFIGURATION
// ============================================
define('SITE_NAME', 'ICT Service Portal');
define('SITE_URL', 'http://localhost/ICT_Service_Portal/');
define('ADMIN_EMAIL', 'admin@serviceportal.com');
define('TIMEZONE', 'Africa/Addis_Ababa');
date_default_timezone_set(TIMEZONE);

// ============================================
// SECURITY CONFIGURATION
// ============================================
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_TIMEOUT', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// ============================================
// FILE UPLOAD CONFIGURATION
// ============================================
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar']);

// ============================================
// EMAIL CONFIGURATION (update with your real credentials)
// ============================================
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
define('SMTP_ENCRYPTION', 'tls');

// ============================================
// ERROR REPORTING
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__DIR__) . '/logs/error.log');
?>
