<?php
require_once 'config.php';

try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $conn->exec("SET NAMES utf8");
    $conn->exec("SET time_zone = '" . date('P') . "'");
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ============================================
// SANITIZATION FUNCTIONS
// ============================================
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function sanitizeFilename($filename) {
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
    return time() . '_' . $filename;
}

// ============================================
// REQUEST TYPE FUNCTIONS
// ============================================
function getRequestTypes() {
    return ['Hardware', 'Software', 'Network', 'Printer', 'Security', 'Email', 'Database', 'Other'];
}

function getPriorityOptions() {
    return ['low' => 'Low', 'medium' => 'Medium', 'high' => 'High', 'critical' => 'Critical'];
}

function getStatusOptions() {
    return [
        'pending' => 'Pending',
        'approved' => 'Approved',
        'in_progress' => 'In Progress',
        'resolved' => 'Resolved',
        'closed' => 'Closed',
        'rejected' => 'Rejected'
    ];
}

function getStatusColor($status) {
    $colors = [
        'pending' => 'warning',
        'approved' => 'info',
        'in_progress' => 'primary',
        'resolved' => 'success',
        'closed' => 'secondary',
        'rejected' => 'danger'
    ];
    return $colors[$status] ?? 'secondary';
}

function getPriorityColor($priority) {
    $colors = ['low' => 'success', 'medium' => 'warning', 'high' => 'danger', 'critical' => 'danger'];
    return $colors[$priority] ?? 'secondary';
}

// ============================================
// PASSWORD VALIDATION (ተጨማሪ)
// ============================================
function validatePassword($password) {
    $errors = [];
    
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        $errors[] = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter';
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must contain at least one lowercase letter';
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one number';
    }
    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $errors[] = 'Password must contain at least one special character';
    }
    
    return $errors;
}

// ============================================
// ACTIVITY LOG FUNCTIONS
// ============================================
function logActivity($user_id, $action, $description = '') {
    global $conn;
    try {
        $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $user_id,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// ============================================
// NOTIFICATION FUNCTIONS
// ============================================
function addNotification($user_id, $type, $title, $message, $link = null) {
    global $conn;
    try {
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $type, $title, $message, $link]);
        return $conn->lastInsertId();
    } catch (PDOException $e) {
        return false;
    }
}

function getUnreadNotifications($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function markNotificationAsRead($notification_id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    return $stmt->execute([$notification_id]);
}

// ============================================
// PERMISSION FUNCTIONS
// ============================================
function hasPermission($user_id, $permission) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM user_permissions WHERE user_id = ? AND permission = ? AND granted = 1");
    $stmt->execute([$user_id, $permission]);
    return $stmt->rowCount() > 0;
}

function grantPermission($user_id, $permission, $granted_by = null) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO user_permissions (user_id, permission, granted_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE granted = 1, granted_by = ?, granted_at = NOW()");
    return $stmt->execute([$user_id, $permission, $granted_by, $granted_by]);
}

function revokePermission($user_id, $permission) {
    global $conn;
    $stmt = $conn->prepare("UPDATE user_permissions SET granted = 0 WHERE user_id = ? AND permission = ?");
    return $stmt->execute([$user_id, $permission]);
}
?>