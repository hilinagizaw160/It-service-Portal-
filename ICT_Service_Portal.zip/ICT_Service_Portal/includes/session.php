<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// SESSION FUNCTIONS
// ============================================
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function isAdmin() {
    return isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'super_admin']);
}

function isSuperAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'super_admin';
}

function isUser() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
}

function checkLogin() {
    if (!isLoggedIn()) {
        setFlashMessage('danger', 'Please login to access this page');
        header('Location: login.php');
        exit();
    }
}

function checkAdmin() {
    checkLogin();
    if (!isAdmin()) {
        setFlashMessage('danger', 'Access denied. Admin privileges required.');
        header('Location: dashboard.php');
        exit();
    }
}

function checkSuperAdmin() {
    checkLogin();
    if (!isSuperAdmin()) {
        setFlashMessage('danger', 'Access denied. Super Admin privileges required.');
        header('Location: admin/admin_dashboard.php');
        exit();
    }
}

function getCurrentUser() {
    if (isLoggedIn()) {
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'full_name' => $_SESSION['full_name'],
            'email' => $_SESSION['email'],
            'role' => $_SESSION['role']
        ];
    }
    return null;
}

// ============================================
// FLASH MESSAGES
// ============================================
function setFlashMessage($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlashMessage() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// ============================================
// LOGOUT
// ============================================
function logout() {
    // Log activity
    if (isLoggedIn()) {
        global $conn;
        try {
            $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        } catch (PDOException $e) {}
    }
    
    session_destroy();
    setFlashMessage('success', 'You have been logged out successfully');
    header('Location: login.php');
    exit();
}

// ============================================
// SESSION TIMEOUT CHECK
// ============================================
function checkSessionTimeout() {
    if (isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
            logout();
        }
    }
    $_SESSION['last_activity'] = time();
}

// Run session timeout check
if (isLoggedIn()) {
    checkSessionTimeout();
}
?>